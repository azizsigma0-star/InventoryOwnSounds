package dev.aziz.inventoryownsounds;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.core.Registry;

public final class ModSounds {
    public static final SoundEvent INVENTORY_OPEN = register("inventory_open");
    public static final SoundEvent INVENTORY_CLOSE = register("inventory_close");

    private ModSounds() {}

    private static SoundEvent register(String path) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(InventoryOwnSounds.MOD_ID, path);
        return Registry.register(
            BuiltInRegistries.SOUND_EVENT,
            id,
            SoundEvent.createVariableRangeEvent(id)
        );
    }

    public static void register() {
        // Static fields trigger registration.
    }
}
