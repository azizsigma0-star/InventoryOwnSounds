package dev.aziz.inventoryownsounds;

import net.fabricmc.api.ModInitializer;

public final class InventoryOwnSounds implements ModInitializer {
    public static final String MOD_ID = "inventoryownsounds";

    @Override
    public void onInitialize() {
        ModSounds.register();
    }
}
