package dev.aziz.inventoryownsounds.mixin;

import dev.aziz.inventoryownsounds.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundSource;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftScreenMixin {
    @Shadow @Nullable public Screen screen;

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void inventoryownsounds$detectInventoryTransition(@Nullable Screen nextScreen, CallbackInfo ci) {
        boolean wasInventory = this.screen instanceof InventoryScreen;
        boolean willBeInventory = nextScreen instanceof InventoryScreen;

        if (!wasInventory && willBeInventory) {
            Minecraft client = (Minecraft) (Object) this;
            client.getSoundManager().play(
                SimpleSoundInstance.forUI(ModSounds.INVENTORY_OPEN, 1.0F)
            );
        } else if (wasInventory && !willBeInventory) {
            Minecraft client = (Minecraft) (Object) this;
            client.getSoundManager().play(
                SimpleSoundInstance.forUI(ModSounds.INVENTORY_CLOSE, 1.0F)
            );
        }
    }
}
