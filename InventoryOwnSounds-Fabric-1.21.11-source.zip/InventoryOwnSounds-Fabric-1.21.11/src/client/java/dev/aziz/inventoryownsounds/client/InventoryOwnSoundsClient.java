package dev.aziz.inventoryownsounds.client;

import net.fabricmc.api.ClientModInitializer;

public final class InventoryOwnSoundsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // The screen transition is handled by MinecraftScreenMixin.
    }
}
