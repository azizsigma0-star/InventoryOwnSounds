# Inventory Own Sounds — Fabric 1.21.11

Mod client-side yang memutar suara OGG milikmu sendiri saat inventory pemain dibuka/ditutup.

## Penting
Ini adalah **source project**, belum berupa file `.jar` siap pasang. Proyek perlu dibuild dengan Java 21 dan Gradle/Fabric Loom. Minecraft 1.21.11 membutuhkan Java 21.

## Pasang suara buatanmu melalui resource pack

Buat struktur berikut di dalam resource pack kamu (di folder `assets/`):

```text
assets/
└── inventoryownsounds/
    ├── sounds.json
    └── sounds/
        ├── inventory_open.ogg
        └── inventory_close.ogg
```

Isi `assets/inventoryownsounds/sounds.json`:

```json
{
  "inventory_open": {
    "sounds": ["inventoryownsounds:inventory_open"]
  },
  "inventory_close": {
    "sounds": ["inventoryownsounds:inventory_close"]
  }
}
```

Salin file suaramu:
- `open.ogg` -> `assets/inventoryownsounds/sounds/inventory_open.ogg`
- `close.ogg` -> `assets/inventoryownsounds/sounds/inventory_close.ogg`

File suara harus OGG Vorbis. Kalau game tidak memainkannya, pastikan pack aktif dan cek `latest.log`.

## Catatan
- Mod hanya untuk sisi client.
- Targetnya layar inventory pemain (`InventoryScreen`), bukan chest/container.
- Versi game ditargetkan persis 1.21.11.
- Ini belum dikompilasi atau diuji dalam game di sesi ini; jangan anggap sudah menjadi JAR siap pakai.
